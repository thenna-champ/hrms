<?php $this->load->view('backend/header'); ?>
<?php $this->load->view('backend/sidebar'); ?> 
         <div class="page-wrapper">
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor"><i class="fa fa-cubes" style="color:#1976d2"></i> Dearness Allowance</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Dearness Allowance</li>
                    </ol>
                </div>
            </div>
            <div class="message"></div> 
            <div class="container-fluid">         
                <div class="row">
                    <div class="col-lg-5">
                        <div class="card card-outline-info">
                                <div class="card-header">
                                    <h4 class="m-b-0 text-white">Add Dearness Allowance</h4>
                                </div>
                                
                                <?php echo validation_errors(); ?>
                                <?php echo $this->upload->display_errors(); ?>
                                <?php echo $this->session->flashdata('feedback'); ?>
                                

                                <div class="card-body">
                                        <form method="post" action="Save_Dra" enctype="multipart/form-data">
                                            <div class="form-body">
                                                <div class="row ">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label class="control-label">Amount</label>
                                                            <input type="text" name="dra" id="dra" value="" class="form-control" placeholder="" minlength="3" required>
                                                        </div>
                                                    </div>
                                                    <!--/span-->
                                                </div>
                                                <!--/row-->
                                            </div>
                                            <div class="form-actions">
                                                <button type="submit" class="btn btn-success"> <i class="fa fa-check"></i> Save</button>
                                                <button type="button" class="btn btn-danger">Cancel</button>
                                            </div>
                                        </form>
                                </div>
                            </div>
                            
                        </div>
                    
                    <div class="col-7">
                        <div class="card card-outline-info">
                            <div class="card-header">
                                <h4 class="m-b-0 text-white">Dearness Allowance List</h4>
                            </div>
                            <?php echo $this->session->flashdata('delsuccess'); ?>
                            
                            <div class="card-body">
                                <div class="table-responsive ">
                                    <table id="draa" class="display  table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Emp Name</th>
                                                <th>Emp Id</th>
                                                <th>Type Of Employee</th>
                                                <th>Dearness Allowance</th>
                                                
                                            </tr>
                                        </thead>
                                                                          
                                        <tbody>
                                            <?php foreach ($dra as $value) { ?>
                                               
                                            <tr>
                                                <td><?php echo $value->first_name;?></td>
                                                <td><?php echo $value->em_id;?></td>
                                                <td><?php echo $value->typeemp;?></td>
                                                <td><?php echo $value->dra;?></td>
                                                
                                                
                                            </tr>
                                            <?php }?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
    <?php $this->load->view('backend/footer'); ?>
    <script>
    $('#draa').DataTable({
        "aaSorting": [[1,'asc']],
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });
</script>