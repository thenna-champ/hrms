-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 28, 2024 at 08:52 PM
-- Server version: 5.7.40
-- PHP Version: 8.1.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hrsystem-ci`
--

-- --------------------------------------------------------

--
-- Table structure for table `addition`
--

DROP TABLE IF EXISTS `addition`;
CREATE TABLE IF NOT EXISTS `addition` (
  `addi_id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_id` int(11) NOT NULL,
  `basic` varchar(128) DEFAULT NULL,
  `dra` varchar(64) DEFAULT NULL,
  `medical` varchar(64) DEFAULT NULL,
  `house_rent` varchar(64) DEFAULT NULL,
  `conveyance` varchar(64) DEFAULT NULL,
  `lta` varchar(64) DEFAULT NULL,
  `attendance_bonus` varchar(64) DEFAULT NULL,
  `bonus` varchar(64) DEFAULT NULL,
  `overtime` varchar(64) DEFAULT NULL,
  `other_allowance` varchar(64) DEFAULT NULL,
  `total_gross` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`addi_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `addition`
--

INSERT INTO `addition` (`addi_id`, `salary_id`, `basic`, `dra`, `medical`, `house_rent`, `conveyance`, `lta`, `attendance_bonus`, `bonus`, `overtime`, `other_allowance`, `total_gross`) VALUES
(1, 1, '2750.00', '200', '275.00', '2200.00', '275.00', NULL, NULL, NULL, NULL, NULL, NULL),
(2, 2, '6750.00', '200', '675.00', '5400.00', '675.00', NULL, NULL, NULL, NULL, NULL, NULL),
(3, 3, '25000.00', '300', '1250', '20000.00', '1000', '100', '200', '300', '385', '500', '48735.00'),
(4, 4, '2782.50', '200', '278.25', '2226.00', '278.25', NULL, NULL, NULL, '803', NULL, NULL),
(5, 5, '3450.00', '200', '345.00', '2760.00', '345.00', NULL, NULL, NULL, NULL, NULL, NULL),
(6, 6, '3975.00', '200', '397.50', '3180.00', '397.50', NULL, NULL, NULL, NULL, NULL, NULL),
(7, 7, '4300.00', '200', '430.00', '3440.00', '430.00', NULL, NULL, NULL, NULL, NULL, NULL),
(8, 8, '5500.00', '200', '550.00', '4400.00', '550.00', NULL, NULL, NULL, NULL, NULL, NULL),
(9, 9, '3500.00', NULL, '350.00', '2800.00', '350.00', NULL, NULL, NULL, NULL, NULL, NULL),
(10, 10, '2800.00', '200', '280.00', '2240.00', '280.00', NULL, NULL, NULL, NULL, NULL, NULL),
(11, 11, '7500.00', '200', '750.00', '6000.00', '750.00', NULL, NULL, NULL, NULL, NULL, NULL),
(12, 12, '10000.00', '200', '1000.00', '8000.00', '1000.00', NULL, NULL, NULL, NULL, NULL, NULL),
(13, 13, '250000.00', '200', '25000.00', '200000.00', '25000.00', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
CREATE TABLE IF NOT EXISTS `address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(64) DEFAULT NULL,
  `city` varchar(128) DEFAULT NULL,
  `country` varchar(128) DEFAULT NULL,
  `address` varchar(512) DEFAULT NULL,
  `type` enum('Present','Permanent') DEFAULT 'Present',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `emp_id`, `city`, `country`, `address`, `type`) VALUES
(1, 'Doe1753', 'Muscle Shoals', 'US', '1669 James M Avenue, chennai', 'Permanent'),
(2, 'Doe1753', 'Muscle Shoals', 'US', '1669 James M Avenue', 'Present'),
(3, 'Soy1332', 'Fordsan', 'US', '778 Blecker Street', 'Permanent'),
(4, 'Soy1332', 'Fordsan', 'US', '778 Blecker Street', 'Present'),
(5, 'Rav1668', 'Chennai ', 'India', 'S/o Srinivasan\r\nThiruvotriyur', 'Permanent');

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
CREATE TABLE IF NOT EXISTS `assets` (
  `ass_id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` varchar(14) NOT NULL,
  `ass_name` varchar(256) DEFAULT NULL,
  `ass_brand` varchar(128) DEFAULT NULL,
  `ass_model` varchar(256) DEFAULT NULL,
  `ass_code` varchar(256) DEFAULT NULL,
  `configuration` varchar(512) DEFAULT NULL,
  `purchasing_date` varchar(128) DEFAULT NULL,
  `ass_price` varchar(128) DEFAULT NULL,
  `ass_qty` varchar(64) DEFAULT NULL,
  `in_stock` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`ass_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `assets`
--

INSERT INTO `assets` (`ass_id`, `catid`, `ass_name`, `ass_brand`, `ass_model`, `ass_code`, `configuration`, `purchasing_date`, `ass_price`, `ass_qty`, `in_stock`) VALUES
(1, '3', 'Laptop T10', 'Dell', 'Alienware', 'AW569', 'demo config demo config demo config', '12/23/2021', '1949', '3', '3');

-- --------------------------------------------------------

--
-- Table structure for table `assets_category`
--

DROP TABLE IF EXISTS `assets_category`;
CREATE TABLE IF NOT EXISTS `assets_category` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_status` enum('ASSETS','LOGISTIC') NOT NULL DEFAULT 'ASSETS',
  `cat_name` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `assets_category`
--

INSERT INTO `assets_category` (`cat_id`, `cat_status`, `cat_name`) VALUES
(1, 'ASSETS', 'TAB'),
(2, 'ASSETS', 'Computer'),
(3, 'ASSETS', 'Laptop'),
(4, 'LOGISTIC', 'tab');

-- --------------------------------------------------------

--
-- Table structure for table `assign_leave`
--

DROP TABLE IF EXISTS `assign_leave`;
CREATE TABLE IF NOT EXISTS `assign_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` varchar(11) NOT NULL,
  `emp_id` varchar(64) DEFAULT NULL,
  `type_id` int(11) NOT NULL,
  `day` varchar(256) DEFAULT NULL,
  `hour` varchar(255) NOT NULL,
  `total_day` varchar(64) DEFAULT NULL,
  `dateyear` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `assign_leave`
--

INSERT INTO `assign_leave` (`id`, `app_id`, `emp_id`, `type_id`, `day`, `hour`, `total_day`, `dateyear`) VALUES
(1, '', 'Moo1402', 2, NULL, '8', NULL, '2021'),
(2, '', 'Tho1044', 2, NULL, '56', NULL, '2022'),
(3, '', 'Den1745', 1, NULL, '8', NULL, '2022'),
(4, '', 'Soy1332', 2, NULL, '8', NULL, '2024'),
(5, '', 'ji1648', 9, '2', '', '0', '2024'),
(6, '', 'ji1648', 4, '10', '', '0', '2024'),
(7, '', 'ji1648', 1, '2', '', '0', '2024'),
(8, '', 'Joh1474', 1, NULL, '2', NULL, '2024');

-- --------------------------------------------------------

--
-- Table structure for table `assign_task`
--

DROP TABLE IF EXISTS `assign_task`;
CREATE TABLE IF NOT EXISTS `assign_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `assign_user` varchar(64) DEFAULT NULL,
  `user_type` enum('Team Head','Collaborators') NOT NULL DEFAULT 'Collaborators',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `assign_task`
--

INSERT INTO `assign_task` (`id`, `task_id`, `project_id`, `assign_user`, `user_type`) VALUES
(1, 1, 1, 'Moo1402', 'Team Head'),
(2, 1, 1, 'Doe1753', 'Collaborators');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
CREATE TABLE IF NOT EXISTS `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(64) DEFAULT NULL,
  `atten_date` varchar(64) DEFAULT NULL,
  `signin_time` time DEFAULT NULL,
  `signout_time` time DEFAULT NULL,
  `working_hour` varchar(64) DEFAULT NULL,
  `place` varchar(255) NOT NULL,
  `absence` varchar(128) DEFAULT NULL,
  `overtime` varchar(128) DEFAULT NULL,
  `earnleave` varchar(128) DEFAULT NULL,
  `status` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1100 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `emp_id`, `atten_date`, `signin_time`, `signout_time`, `working_hour`, `place`, `absence`, `overtime`, `earnleave`, `status`) VALUES
(1012, '6969', '2021-06-04', '10:00:00', '03:04:00', '06 h 56 m', 'field', NULL, NULL, NULL, 'E'),
(1013, '6969', '2021-06-06', '09:00:00', '02:00:00', '07 h 0 m', 'office', NULL, NULL, NULL, 'A'),
(1014, '123456', '2021-12-01', '09:00:00', '04:30:00', '04 h 30 m', 'office', NULL, NULL, NULL, 'A'),
(1015, '123444', '2021-12-29', '09:00:00', '03:00:00', '06 h 0 m', 'office', NULL, NULL, NULL, 'A'),
(1016, '3008', '2021-12-28', '10:00:00', '03:23:00', '06 h 37 m', 'office', NULL, NULL, NULL, 'A'),
(1017, '6600', '2022-01-02', '10:00:00', '04:00:00', '06 h 0 m', 'office', NULL, NULL, NULL, 'E'),
(1018, '8829', '2022-01-02', '10:00:00', '04:05:00', '05 h 55 m', 'office', NULL, NULL, NULL, 'E'),
(1019, '6600', '2021-11-30', '10:00:00', '05:00:00', '05 h 0 m', 'office', NULL, NULL, NULL, 'A'),
(1020, '9990', '2024-09-01', '08:00:00', '20:00:00', '12 h 0 m', 'office', NULL, NULL, NULL, 'A'),
(1021, '99', '2019-05-16', '12:00:00', '04:05:00', '48 min', 'office', '0 min', '0 min', NULL, 'A'),
(1022, '100', '2020-05-16', '12:00:00', '04:05:00', '49 min', 'office', '1 min', '1 min', NULL, 'A'),
(1023, '12', '2021-05-16', '12:00:00', '04:05:00', '50 min', 'office', '2 min', '2 min', NULL, 'A'),
(1024, '20', '2022-05-16', '12:00:00', '04:05:00', '51 min', 'office', '3 min', '3 min', NULL, 'A'),
(1025, '4', '2023-05-16', '12:00:00', '04:05:00', '52 min', 'office', '4 min', '4 min', NULL, 'A'),
(1026, '4', '2024-05-16', '12:00:00', '04:05:00', '53 min', 'office', '5 min', '5 min', NULL, 'A'),
(1027, '4', '2025-05-16', '12:00:00', '04:05:00', '54 min', 'office', '6 min', '6 min', NULL, 'A'),
(1028, '4', '2026-05-16', '12:00:00', '04:05:00', '55 min', 'office', '7 min', '7 min', NULL, 'A'),
(1029, '4', '2027-05-16', '12:00:00', '04:05:00', '56 min', 'office', '8 min', '8 min', NULL, 'A'),
(1030, '4', '2028-05-16', '12:00:00', '04:05:00', '57 min', 'office', '9 min', '9 min', NULL, 'A'),
(1031, '4', '2029-05-16', '12:00:00', '04:05:00', '58 min', 'office', '10 min', '10 min', NULL, 'A'),
(1032, '4', '2030-05-16', '12:00:00', '04:05:00', '59 min', 'office', '11 min', '11 min', NULL, 'A'),
(1033, '4', '2031-05-16', '12:00:00', '04:05:00', '60 min', 'office', '12 min', '12 min', NULL, 'A'),
(1034, '4', '2032-05-16', '12:00:00', '04:05:00', '61 min', 'office', '13 min', '13 min', NULL, 'A'),
(1035, '4', '2033-05-16', '12:00:00', '04:05:00', '62 min', 'office', '14 min', '14 min', NULL, 'A'),
(1036, '99', '2024-01-05', '12:00:00', '04:05:00', '48 min', 'office', '0 min', '0 min', NULL, 'A'),
(1037, '99', '2024-01-10', '12:00:00', '04:05:00', '48 min', 'office', '0 min', '0 min', NULL, 'A'),
(1038, '99', '2024-02-10', '12:00:00', '04:05:00', '48 min', 'office', '0 min', '0 min', NULL, 'A'),
(1039, '99', '2024-03-10', '12:00:00', '04:05:00', '48 min', 'office', '0 min', '0 min', NULL, 'A'),
(1040, '99', '2024-04-10', '12:00:00', '04:05:00', '48 min', 'office', '0 min', '0 min', NULL, 'A'),
(1041, '99', '2024-05-10', '12:00:00', '04:05:00', '48 min', 'office', '0 min', '0 min', NULL, 'A'),
(1042, '99', '2024-06-10', '12:00:00', '04:05:00', '48 min', 'office', '0 min', '0 min', NULL, 'A'),
(1043, '99', '2024-07-10', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1044, '99', '2024-08-10', '12:00:00', '04:05:00', '48 min', 'office', '0 min', '0 min', NULL, 'A'),
(1045, '99', '2024-09-10', '12:00:00', '04:05:00', '48 min', 'office', '0 min', '0 min', NULL, 'A'),
(1046, '99', '2024-10-10', '12:00:00', '04:05:00', '48 min', 'office', '0 min', '0 min', NULL, 'A'),
(1047, '99', '2024-11-10', '12:00:00', '04:05:00', '48 min', 'office', '0 min', '0 min', NULL, 'A'),
(1048, '99', '2024-12-10', '12:00:00', '04:05:00', '48 min', 'office', '0 min', '0 min', NULL, 'A'),
(1049, '99', '1970-01-01', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1050, '99', '2024-01-09', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1051, '99', '2024-02-09', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1052, '99', '2024-03-09', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1053, '99', '2024-04-09', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1054, '99', '2024-05-09', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1055, '99', '2024-06-09', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1056, '99', '2024-07-09', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1057, '99', '2024-08-09', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1058, '99', '2024-09-09', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1059, '99', '2024-10-09', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1060, '99', '2024-11-09', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1061, '99', '2024-12-09', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1062, '99', '2024-01-08', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1063, '99', '2024-02-08', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1064, '99', '2024-03-08', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1065, '99', '2024-04-08', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1066, '99', '2024-05-08', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1067, '99', '2024-06-08', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1068, '99', '2024-07-08', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1069, '99', '2024-08-08', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1070, '99', '2024-09-08', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1071, '99', '2024-10-08', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1072, '99', '2024-11-08', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1073, '99', '2024-12-08', '12:00:00', '04:05:00', '08 h 0min', 'office', '0 min', '0 min', NULL, 'A'),
(1074, '99', '2024-07-01', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1075, '99', '2024-07-02', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1076, '99', '2024-07-03', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1077, '99', '2024-07-04', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1078, '99', '2024-07-05', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1079, '99', '2024-07-06', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1080, '99', '2024-07-07', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1081, '99', '2024-07-11', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1082, '99', '2024-07-12', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1083, '99', '2024-07-13', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1084, '99', '2024-07-14', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1085, '99', '2024-07-15', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1086, '99', '2024-07-16', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1087, '99', '2024-07-17', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1088, '99', '2024-07-18', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1089, '99', '2024-07-19', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1090, '99', '2024-07-20', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1091, '99', '2024-07-21', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1092, '99', '2024-07-22', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1093, '99', '2024-07-23', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1094, '99', '2024-07-24', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1095, '99', '2024-07-25', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1096, '99', '2024-07-26', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1097, '99', '2024-07-27', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1098, '99', '2024-07-28', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A'),
(1099, '99', '2024-07-29', '12:00:00', '04:05:00', '8 h 0 min', 'office', '0 min', '0 min', NULL, 'A');

-- --------------------------------------------------------

--
-- Table structure for table `bank_info`
--

DROP TABLE IF EXISTS `bank_info`;
CREATE TABLE IF NOT EXISTS `bank_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `em_id` varchar(64) DEFAULT NULL,
  `holder_name` varchar(256) DEFAULT NULL,
  `bank_name` varchar(256) DEFAULT NULL,
  `branch_name` varchar(256) DEFAULT NULL,
  `account_number` varchar(256) DEFAULT NULL,
  `account_type` varchar(256) DEFAULT NULL,
  `ifsc_code` varchar(65) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bank_info`
--

INSERT INTO `bank_info` (`id`, `em_id`, `holder_name`, `bank_name`, `branch_name`, `account_number`, `account_type`, `ifsc_code`) VALUES
(1, 'Doe1754', 'John W Greenwood', 'XYZ Bank', 'Bleck St', 'CA0025869690', 'Saving', NULL),
(2, 'Doe1753', 'Will Williams', 'ABYZ Bank', 'Axis Branch', 'CA6960000142', 'Current', NULL),
(3, 'Soy1332', 'Thomas Anderson', 'United Bank', 'ABC Branch', 'CA100005696920', 'Salary Account', 'HDFC000581'),
(4, 'Rob1472', 'Stephany Robs Jr', 'United Bank', 'ABC Branch', 'CA140000000255', 'Savings', NULL),
(5, 'Tho1044', 'Chris Thompson', 'YTR Bank', 'XY Branch', 'CA7025000026', 'Savings', NULL),
(6, 'Moo1402', 'Liam Moore', 'IOP Bank', 'AER Branch', 'CA690000250000', 'Salary Account', NULL),
(7, 'Smi1266', 'Colin Smith', 'IO Bank', 'CVB Branch', 'CA001450006980', 'Salary Account', NULL),
(8, 'Moo1634', 'Christine Moore', 'RTY Bank', 'ERT Branch', 'CA850000245800', 'Savings', NULL),
(9, 'Joh1474', 'Michael K Johnson', 'Aexr Bank', 'ERT Branch', 'CA800000256147', 'Salary Account', NULL),
(10, 'Den1745', 'Emily V Denn', 'Demo Bank', 'XZY Branch', 'CA777000001055', 'Savings', NULL),
(11, 'Rav1668', 'Dev aathishes', 'ICICI', 'Pariys ', '00012345677', 'Savings', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `canteen`
--

DROP TABLE IF EXISTS `canteen`;
CREATE TABLE IF NOT EXISTS `canteen` (
  `Id` int(64) NOT NULL AUTO_INCREMENT,
  `emp_id` int(64) NOT NULL,
  `canteen_spend` int(64) NOT NULL,
  `latest_update` date NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `canteen`
--

INSERT INTO `canteen` (`Id`, `emp_id`, `canteen_spend`, `latest_update`) VALUES
(1, 99, 300, '2024-06-26'),
(2, 1058, 100, '2024-06-26'),
(3, 99, 300, '2024-09-26'),
(4, 1058, 100, '2024-09-26'),
(5, 99, 300, '2024-10-26'),
(6, 1058, 100, '2024-10-26');

-- --------------------------------------------------------

--
-- Table structure for table `deduction`
--

DROP TABLE IF EXISTS `deduction`;
CREATE TABLE IF NOT EXISTS `deduction` (
  `de_id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_id` int(11) NOT NULL,
  `provident_fund` varchar(64) DEFAULT NULL,
  `bima` varchar(64) DEFAULT NULL,
  `tax` varchar(64) DEFAULT NULL,
  `others` varchar(64) DEFAULT NULL,
  `esi` varchar(64) DEFAULT NULL,
  `professionaltax` varchar(64) DEFAULT NULL,
  `canteen` varchar(64) DEFAULT NULL,
  `lwf` varchar(64) DEFAULT NULL,
  `totaldeduction` varchar(64) DEFAULT NULL,
  `latest_update` date DEFAULT NULL,
  PRIMARY KEY (`de_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `deduction`
--

INSERT INTO `deduction` (`de_id`, `salary_id`, `provident_fund`, `bima`, `tax`, `others`, `esi`, `professionaltax`, `canteen`, `lwf`, `totaldeduction`, `latest_update`) VALUES
(1, 1, '400', '0', '10', '0', NULL, NULL, NULL, NULL, NULL, NULL),
(2, 2, '250', '360', '10', '0', NULL, NULL, NULL, NULL, NULL, NULL),
(3, 3, '3048.00', '100', '100', '100', '366', '208', '300', '100', '3848.00', NULL),
(4, 4, '0', '0', '5', '0', NULL, NULL, '100', NULL, NULL, NULL),
(5, 5, '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL),
(6, 6, '265', '0', '10', '0', NULL, NULL, NULL, NULL, NULL, NULL),
(7, 7, '200', '300', '7', '0', NULL, NULL, NULL, NULL, NULL, NULL),
(8, 8, '300', '560', '10', '0', NULL, NULL, NULL, NULL, NULL, NULL),
(9, 9, '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL),
(10, 10, '0', '100', '10', '0', NULL, NULL, NULL, NULL, NULL, NULL),
(11, 11, '1500', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL),
(12, 12, '1200', '1000', '', '', NULL, NULL, NULL, NULL, NULL, NULL),
(13, 13, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE IF NOT EXISTS `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dep_name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `dep_name`) VALUES
(2, 'Administrations'),
(3, 'Finance, HR, & Admininstration'),
(4, 'Research'),
(5, 'Information Technology'),
(6, 'Support'),
(7, 'Network Engineering'),
(8, 'Sales and Marketing'),
(9, 'Helpdesk'),
(10, 'Project Management');

-- --------------------------------------------------------

--
-- Table structure for table `desciplinary`
--

DROP TABLE IF EXISTS `desciplinary`;
CREATE TABLE IF NOT EXISTS `desciplinary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `em_id` varchar(64) DEFAULT NULL,
  `action` varchar(256) DEFAULT NULL,
  `title` varchar(256) DEFAULT NULL,
  `description` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `desciplinary`
--

INSERT INTO `desciplinary` (`id`, `em_id`, `action`, `title`, `description`) VALUES
(1, 'Soy1332', 'Writing Warning', 'Test Test Test', 'Test Test Test Test'),
(2, 'Soy1332', 'Verbel Warning', 'sdfsdfsdfsdf', 'sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsd');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

DROP TABLE IF EXISTS `designation`;
CREATE TABLE IF NOT EXISTS `designation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `des_name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`id`, `des_name`) VALUES
(2, 'Vice Chairman'),
(3, 'Chief Executive Officer (CEO)'),
(4, 'Chief Finance & Admin Officer'),
(5, 'Sr. Finance & Admin Officer - I'),
(6, 'Jr. Finance & Admin Officer'),
(7, 'Senior Research Associate-1'),
(8, 'Research Associate-1'),
(9, 'Junior Research Associate'),
(10, 'Research Assistant'),
(11, 'Sr. Office Assistant'),
(12, 'Office Assistant'),
(13, 'IT Analyst'),
(14, 'Cook'),
(15, 'Software Engineer'),
(16, 'System Analyst'),
(17, 'Programmer Analyst'),
(18, 'Sr Software Engineer'),
(19, 'Technical Specialist'),
(20, 'Trainee Engineer'),
(21, 'Intern'),
(22, 'Head of Department'),
(23, 'Business Analyst'),
(24, 'Web Developer'),
(25, 'Big Data Engineer'),
(26, 'Project Manager'),
(27, 'Trainee');

-- --------------------------------------------------------

--
-- Table structure for table `earned_leave`
--

DROP TABLE IF EXISTS `earned_leave`;
CREATE TABLE IF NOT EXISTS `earned_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `em_id` varchar(64) DEFAULT NULL,
  `present_date` varchar(64) DEFAULT NULL,
  `hour` varchar(64) DEFAULT NULL,
  `status` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `earned_leave`
--

INSERT INTO `earned_leave` (`id`, `em_id`, `present_date`, `hour`, `status`) VALUES
(26, 'Mir1685', '0', '0', '1'),
(27, 'Rah1682', '0', '0', '1'),
(28, 'edr1432', '0', '0', '1');

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

DROP TABLE IF EXISTS `education`;
CREATE TABLE IF NOT EXISTS `education` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(128) DEFAULT NULL,
  `edu_type` varchar(256) DEFAULT NULL,
  `institute` varchar(256) DEFAULT NULL,
  `result` varchar(64) DEFAULT NULL,
  `year` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`id`, `emp_id`, `edu_type`, `institute`, `result`, `year`) VALUES
(1, 'Doe1753', 'MSIT', 'Westview University', '71', '2016'),
(2, 'Rav1668', 'B.Tech IT ', 'Muthukumaran Technologies ', 'A+', '2020');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `em_id` varchar(64) DEFAULT NULL,
  `em_code` varchar(64) DEFAULT NULL,
  `des_id` int(11) DEFAULT NULL,
  `dep_id` int(11) DEFAULT NULL,
  `sec_id` int(11) DEFAULT NULL,
  `first_name` varchar(128) DEFAULT NULL,
  `last_name` varchar(128) DEFAULT NULL,
  `em_email` varchar(64) DEFAULT NULL,
  `em_password` varchar(512) NOT NULL,
  `em_role` enum('ADMIN','EMPLOYEE','SUPER ADMIN') NOT NULL DEFAULT 'EMPLOYEE',
  `typeemp` enum('STAFF','WORKER') NOT NULL DEFAULT 'WORKER',
  `em_address` varchar(512) DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  `em_gender` enum('Male','Female') NOT NULL DEFAULT 'Male',
  `em_phone` varchar(64) DEFAULT NULL,
  `em_birthday` varchar(128) DEFAULT NULL,
  `em_blood_group` enum('O+','O-','A+','A-','B+','B-','AB+','OB+') DEFAULT NULL,
  `em_joining_date` varchar(128) DEFAULT NULL,
  `em_contact_end` varchar(128) DEFAULT NULL,
  `em_image` varchar(128) DEFAULT NULL,
  `em_nid` varchar(64) DEFAULT NULL,
  `em_pan` varchar(96) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `em_id`, `em_code`, `des_id`, `dep_id`, `sec_id`, `first_name`, `last_name`, `em_email`, `em_password`, `em_role`, `typeemp`, `em_address`, `status`, `em_gender`, `em_phone`, `em_birthday`, `em_blood_group`, `em_joining_date`, `em_contact_end`, `em_image`, `em_nid`, `em_pan`) VALUES
(10, 'Soy1332', '99', 0, 2, 0, 'Thom', 'Anderson', 'thoma@mail.com', '25c2c9afdd83b8d34234aa2881cc341C09689aaa', 'SUPER ADMIN', 'WORKER', NULL, 'ACTIVE', 'Female', '7856587870', '1985-12-05', 'B+', '2018-01-06', '2018-01-06', 'userav-min.png', '132154566556', 'werwer12312'),
(36, 'Doe1753', '123456', 2, 2, 0, 'Will', 'Williams', 'admin@mail.com', 'cd5ea73cd58f827fa78eef7197b8ee606c99b2e6', 'ADMIN', 'WORKER', NULL, 'ACTIVE', 'Male', '9043803878', '1990-12-13', 'O+', '2019-02-15', '2019-02-22', 'user.png', '01253568955555', 'PAN1234567'),
(37, 'Doe1754', '123444', 12, 2, 0, 'John', 'Greenwood', 'employee@mail.com', 'cd5ea73cd58f827fa78eef7197b8ee606c99b2e6', 'EMPLOYEE', 'WORKER', NULL, 'ACTIVE', 'Male', '1111110010', '1995-10-30', 'O+', '2019-02-15', '2019-02-22', 'Doe1753.jpg', '01253568955555', ''),
(38, 'Moo1402', '6969', 13, 5, 0, 'Liam', 'Moore', 'liam@mail.com', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'EMPLOYEE', 'WORKER', NULL, 'ACTIVE', 'Male', '7124589965', '1994-03-23', 'A-', '2021-05-04', '2023-05-17', 'Moo1402.png', '1234567890', ''),
(39, 'Rob1472', '1058', 9, 4, 0, 'Stephany', 'Robs', 'stephany@mail.com', '7672fb4033bc7bc14e2e26e5e0679e3c2a1bd514', 'EMPLOYEE', 'WORKER', NULL, 'ACTIVE', 'Female', '7850001111', '1992-12-24', 'A+', '2021-04-14', '', 'Rob1472.png', '7000105000', ''),
(40, 'Tho1044', '8877', 5, 5, 0, 'Chris', 'Thompson', 'chris@mail.com', '260a678229cde1991cd1ac0d6adb4980c76c5e7f', 'EMPLOYEE', 'STAFF', NULL, 'ACTIVE', 'Male', '7852140000', '1993-01-02', 'AB+', '2021-10-01', '', 'Tho1044.png', '0102580010', '1234567894'),
(41, 'Smi1266', '3008', 23, 8, 0, 'Colin', 'Smith', 'colin@mail.com', '7b4286b09972e2859b718440aa68a2a6eeb869dd', 'EMPLOYEE', 'WORKER', NULL, 'ACTIVE', 'Male', '7400001450', '1990-12-12', 'B+', '2021-10-10', '', 'Smi1266.png', '0147000000', ''),
(42, 'Moo1634', '6661', 26, 10, 0, 'Christine', 'Moore', 'christine@mail.com', '37219392e904e98b6dca4f729f1d29c642d40e19', 'EMPLOYEE', 'WORKER', NULL, 'ACTIVE', 'Female', '1010140000', '1991-04-05', 'A-', '2021-10-10', '', 'Moo1634.png', '147850000144', ''),
(43, 'Joh1474', '8829', 22, 7, 0, 'Michael', 'Johnson', 'michael@mail.com', 'd492ed1b1fdfbc9ca9db7c10c7df38d2b488fb14', 'EMPLOYEE', 'WORKER', NULL, 'ACTIVE', 'Male', '7801450000', '1986-02-23', 'B-', '2021-02-02', '', 'Joh1474.png', '600254000014', ''),
(44, 'Den1745', '6600', 20, 7, 0, 'Emily', 'Denn', 'emily@mail.com', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'EMPLOYEE', 'WORKER', NULL, 'ACTIVE', 'Female', '7410144470', '1996-03-03', 'AB+', '2021-10-10', '', 'Den1745.png', '880024520000', ''),
(45, 'tes1397', '9990', 0, 0, 0, 'test', 'test', 'h@gmail.com', '01e3f84a31f9a71ab62db14326f62fbe0a1de0d4', '', 'WORKER', NULL, 'ACTIVE', '', '9987456122', '2017-06-08', '', '', '', NULL, '123456789123', '321654987d'),
(46, 'Rav1668', '100', 9, 9, 6, 'Dav', 'Srinivasan', 'deva@gmail.com', 'a83e8246ab12d0bebb9315fcf20dbf28059428b1', 'EMPLOYEE', 'WORKER', NULL, 'ACTIVE', 'Male', '9500053650', '2000-06-06', 'B+', '2024-09-01', '', 'Rav1668.jpg', '123456789987', 'BAVAA12345'),
(47, 'ji1648', '9902', 14, 2, 0, 'Gopal', 'ji', 'go@gmail.com', 'a0e93016da9fd679ff081c1384f67de65c2b1485', 'EMPLOYEE', 'WORKER', NULL, 'ACTIVE', 'Male', '9987456123', '1987-02-28', 'B+', '2024-09-19', '', NULL, '12345678978', '1234567823'),
(48, 'sek1549', '7894', 2, 6, NULL, 'thenna', 'sekar', 'sthenna0406@gmail.com', '3be5ea3806244f48ca628f4075c2651b8338b46a', 'SUPER ADMIN', 'WORKER', NULL, 'ACTIVE', 'Male', '3214569875', '1986-04-04', '', '2024-10-04', '', NULL, '13265479444', 'AMIPT0776E'),
(49, 'the1037', '9999', 3, 5, 6, 'dhanshika', 'thenna', 't@gmail.com', '1a0e5b7a13faffd3ffd6ae5e2d4fcfbe8abf31f6', 'SUPER ADMIN', 'WORKER', NULL, 'ACTIVE', 'Female', '9551492180', '1986-04-04', 'B+', '2024-10-04', '', NULL, '7894561135', 'AMIPT0776E'),
(50, 'sek1873', '9997', 14, 2, 6, 'test', 'sekar', 'ts@gmail.com', '1a0e5b7a13faffd3ffd6ae5e2d4fcfbe8abf31f6', 'EMPLOYEE', 'WORKER', NULL, 'ACTIVE', 'Male', '9551492180', '1986-04-04', 'A+', '2024-10-04', '', NULL, '7894561135', '78945612345'),
(51, 'the1756', '9933', 15, 2, 6, 'test', 'thenna', 'st@gmail.com', '1a0e5b7a13faffd3ffd6ae5e2d4fcfbe8abf31f6', 'EMPLOYEE', 'STAFF', NULL, 'ACTIVE', 'Male', '9551492180', '1986-04-04', 'AB+', '2024-10-04', '', NULL, '7894561135', 'werwer12312');

-- --------------------------------------------------------

--
-- Table structure for table `employee_file`
--

DROP TABLE IF EXISTS `employee_file`;
CREATE TABLE IF NOT EXISTS `employee_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `em_id` varchar(64) DEFAULT NULL,
  `file_title` varchar(512) DEFAULT NULL,
  `file_url` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee_file`
--

INSERT INTO `employee_file` (`id`, `em_id`, `file_title`, `file_url`) VALUES
(1, 'Rav1668', 'B.Tech Graduations certificate ', 'CV-Mohammed.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `emp_assets`
--

DROP TABLE IF EXISTS `emp_assets`;
CREATE TABLE IF NOT EXISTS `emp_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `assets_id` int(11) NOT NULL,
  `given_date` date NOT NULL,
  `return_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `emp_experience`
--

DROP TABLE IF EXISTS `emp_experience`;
CREATE TABLE IF NOT EXISTS `emp_experience` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(256) DEFAULT NULL,
  `exp_company` varchar(128) DEFAULT NULL,
  `exp_com_position` varchar(128) DEFAULT NULL,
  `exp_com_address` varchar(128) DEFAULT NULL,
  `exp_workduration` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `emp_experience`
--

INSERT INTO `emp_experience` (`id`, `emp_id`, `exp_company`, `exp_com_position`, `exp_com_address`, `exp_workduration`) VALUES
(1, 'Rav1668', 'Tata consultancy ', 'IT Support', 'Chennai ', '2 Years ');

-- --------------------------------------------------------

--
-- Table structure for table `emp_leave`
--

DROP TABLE IF EXISTS `emp_leave`;
CREATE TABLE IF NOT EXISTS `emp_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `em_id` varchar(64) DEFAULT NULL,
  `typeid` int(11) NOT NULL,
  `leave_type` varchar(64) DEFAULT NULL,
  `start_date` varchar(64) DEFAULT NULL,
  `end_date` varchar(64) DEFAULT NULL,
  `leave_duration` varchar(128) DEFAULT NULL,
  `apply_date` varchar(64) DEFAULT NULL,
  `reason` varchar(1024) DEFAULT NULL,
  `leave_status` enum('Approve','Not Approve','Rejected') NOT NULL DEFAULT 'Not Approve',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_leave`
--

INSERT INTO `emp_leave` (`id`, `em_id`, `typeid`, `leave_type`, `start_date`, `end_date`, `leave_duration`, `apply_date`, `reason`, `leave_status`) VALUES
(1, 'Moo1402', 2, 'Full Day', '2021-06-24', '', '8', '2021-06-23', 'a bit of a headache and cough', 'Approve'),
(2, 'Tho1044', 2, 'More than One day', '2022-01-02', '2022-01-09', '56', '2022-01-02', 'Common Cold with Headache', 'Approve'),
(3, 'Joh1474', 1, 'Full Day', '2022-01-03', '', '8', '2022-01-03', 'This is just a demo reason for testing!', 'Rejected'),
(4, 'Joh1474', 1, 'Half Day', '2022-01-03', '', '2', '2022-01-03', 'Demo Test Demo Test Demo', 'Approve'),
(5, 'Den1745', 1, 'Full Day', '2022-01-04', '', '8', '2022-01-03', 'demo demo demo demo demo demo', 'Approve'),
(6, 'Soy1332', 2, 'Full Day', '2024-09-02', '', '8', '2024-09-27', 'sick', 'Approve');

-- --------------------------------------------------------

--
-- Table structure for table `emp_penalty`
--

DROP TABLE IF EXISTS `emp_penalty`;
CREATE TABLE IF NOT EXISTS `emp_penalty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `penalty_id` int(11) NOT NULL,
  `penalty_desc` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `emp_salary`
--

DROP TABLE IF EXISTS `emp_salary`;
CREATE TABLE IF NOT EXISTS `emp_salary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(64) DEFAULT NULL,
  `type_id` int(11) NOT NULL,
  `total` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `emp_salary`
--

INSERT INTO `emp_salary` (`id`, `emp_id`, `type_id`, `total`) VALUES
(1, 'Doe1754', 2, '5500'),
(2, 'Doe1753', 2, '13500'),
(3, 'Soy1332', 2, '50000'),
(4, 'Rob1472', 2, '5565'),
(5, 'Moo1402', 2, '6900'),
(6, 'Smi1266', 2, '7950'),
(7, 'Moo1634', 2, '8600'),
(8, 'Joh1474', 2, '11000'),
(9, 'Tho1044', 2, '7000'),
(10, 'Den1745', 2, '5600'),
(11, 'tes1397', 2, '15000'),
(12, 'Rav1668', 2, '20000'),
(13, 'ji1648', 2, '500000');

-- --------------------------------------------------------

--
-- Table structure for table `emp_training`
--

DROP TABLE IF EXISTS `emp_training`;
CREATE TABLE IF NOT EXISTS `emp_training` (
  `id` int(11) NOT NULL,
  `trainig_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `field_visit`
--

DROP TABLE IF EXISTS `field_visit`;
CREATE TABLE IF NOT EXISTS `field_visit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` varchar(256) NOT NULL,
  `emp_id` varchar(64) DEFAULT NULL,
  `field_location` varchar(512) NOT NULL,
  `start_date` varchar(64) DEFAULT NULL,
  `approx_end_date` varchar(28) NOT NULL,
  `total_days` varchar(64) DEFAULT NULL,
  `notes` varchar(500) NOT NULL,
  `actual_return_date` varchar(28) NOT NULL,
  `status` enum('Approved','Not Approve','Rejected') NOT NULL DEFAULT 'Not Approve',
  `attendance_updated` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `holiday`
--

DROP TABLE IF EXISTS `holiday`;
CREATE TABLE IF NOT EXISTS `holiday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `holiday_name` varchar(256) DEFAULT NULL,
  `from_date` varchar(64) DEFAULT NULL,
  `to_date` varchar(64) DEFAULT NULL,
  `number_of_days` varchar(64) DEFAULT NULL,
  `year` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `holiday`
--

INSERT INTO `holiday` (`id`, `holiday_name`, `from_date`, `to_date`, `number_of_days`, `year`) VALUES
(1, 'New Year\'s Eve', '2021-12-30', '2022-01-31', '32', '12-2021'),
(3, 'New Year\'s Day', '2022-01-01', '2022-01-02', '1', '01-2022'),
(5, 'Christmas', '2021-12-23', '2021-12-25', '2', '12-2021'),
(6, 'Thanksgiving', '2021-11-23', '2021-11-26', '3', '11-2021'),
(7, 'Halloween', '2021-10-31', '2021-10-31', '0', '10-2021'),
(8, 'Saint Patrick\'s Day', '2021-03-17', '2021-03-17', '0', '03-2021');

-- --------------------------------------------------------

--
-- Table structure for table `leave_types`
--

DROP TABLE IF EXISTS `leave_types`;
CREATE TABLE IF NOT EXISTS `leave_types` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `leave_day` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leave_types`
--

INSERT INTO `leave_types` (`type_id`, `name`, `leave_day`, `status`) VALUES
(1, 'Casual Leave', '21', 1),
(2, 'Sick Leave', '15', 1),
(3, 'Maternity Leave', '90', 1),
(4, 'Paternal Leave', '7', 1),
(5, 'Earned leave', '', 1),
(7, 'Public Holiday', '', 1),
(8, 'Optional Leave', '', 1),
(9, 'Leave without Pay', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

DROP TABLE IF EXISTS `loan`;
CREATE TABLE IF NOT EXISTS `loan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(256) DEFAULT NULL,
  `amount` varchar(256) DEFAULT NULL,
  `interest_percentage` varchar(256) DEFAULT NULL,
  `total_amount` varchar(64) DEFAULT NULL,
  `total_pay` varchar(64) DEFAULT NULL,
  `total_due` varchar(64) DEFAULT NULL,
  `installment` varchar(256) DEFAULT NULL,
  `loan_number` varchar(256) DEFAULT NULL,
  `loan_details` varchar(256) DEFAULT NULL,
  `approve_date` varchar(256) DEFAULT NULL,
  `install_period` varchar(256) DEFAULT NULL,
  `status` enum('Granted','Deny','Pause','Done') NOT NULL DEFAULT 'Pause',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`id`, `emp_id`, `amount`, `interest_percentage`, `total_amount`, `total_pay`, `total_due`, `installment`, `loan_number`, `loan_details`, `approve_date`, `install_period`, `status`) VALUES
(1, 'Doe1753', '65000', NULL, NULL, '10833', '54167', '10833', '19073382', 'this is a demo loan test for demo purpose', '2021-04-20', '5', 'Granted'),
(2, 'tes1397', '1000', NULL, NULL, '0', '0', '200', '17848276', 'rttertertertert erterter', '2024-09-28', '5', 'Granted');

-- --------------------------------------------------------

--
-- Table structure for table `loan_installment`
--

DROP TABLE IF EXISTS `loan_installment`;
CREATE TABLE IF NOT EXISTS `loan_installment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_id` int(11) NOT NULL,
  `emp_id` varchar(64) DEFAULT NULL,
  `loan_number` varchar(256) DEFAULT NULL,
  `install_amount` varchar(256) DEFAULT NULL,
  `pay_amount` varchar(64) DEFAULT NULL,
  `app_date` varchar(256) DEFAULT NULL,
  `receiver` varchar(256) DEFAULT NULL,
  `install_no` varchar(256) DEFAULT NULL,
  `notes` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `loan_installment`
--

INSERT INTO `loan_installment` (`id`, `loan_id`, `emp_id`, `loan_number`, `install_amount`, `pay_amount`, `app_date`, `receiver`, `install_no`, `notes`) VALUES
(32, 1, 'Doe1753', '19073382', '10833', NULL, '2021-11-30', NULL, '5', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `logistic_asset`
--

DROP TABLE IF EXISTS `logistic_asset`;
CREATE TABLE IF NOT EXISTS `logistic_asset` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `qty` varchar(64) DEFAULT NULL,
  `entry_date` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `logistic_asset`
--

INSERT INTO `logistic_asset` (`log_id`, `name`, `qty`, `entry_date`) VALUES
(1, 'Lubricant', '30', '12/25/17');

-- --------------------------------------------------------

--
-- Table structure for table `logistic_assign`
--

DROP TABLE IF EXISTS `logistic_assign`;
CREATE TABLE IF NOT EXISTS `logistic_assign` (
  `ass_id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `assign_id` varchar(64) DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `log_qty` varchar(64) DEFAULT NULL,
  `start_date` varchar(64) DEFAULT NULL,
  `end_date` varchar(64) DEFAULT NULL,
  `back_date` varchar(64) DEFAULT NULL,
  `back_qty` varchar(64) DEFAULT NULL,
  `remarks` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`ass_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
CREATE TABLE IF NOT EXISTS `notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `file_url` varchar(256) DEFAULT NULL,
  `date` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`id`, `title`, `file_url`, `date`) VALUES
(1, 'This is a demo notice for all!', 'sample_image.jpg', '2022-01-01'),
(2, 'Office Decorum Notice to Staff Members', 'offnot1.png', '2021-12-21'),
(3, 'Warning for Violation of Office Decorum', 'offnot2.png', '2021-12-27');

-- --------------------------------------------------------

--
-- Table structure for table `overtime`
--

DROP TABLE IF EXISTS `overtime`;
CREATE TABLE IF NOT EXISTS `overtime` (
  `id` int(64) NOT NULL AUTO_INCREMENT,
  `emp_id` int(64) NOT NULL,
  `over_time` int(64) NOT NULL,
  `overtime_allowance` int(11) NOT NULL,
  `latest_update` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `overtime`
--

INSERT INTO `overtime` (`id`, `emp_id`, `over_time`, `overtime_allowance`, `latest_update`) VALUES
(42, 1058, 15, 803, '2024-10-26'),
(41, 99, 10, 385, '2024-10-26');

-- --------------------------------------------------------

--
-- Table structure for table `owner`
--

DROP TABLE IF EXISTS `owner`;
CREATE TABLE IF NOT EXISTS `owner` (
  `id` int(11) NOT NULL,
  `owner_name` varchar(64) NOT NULL,
  `owner_position` varchar(64) DEFAULT NULL,
  `note` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pay_salary`
--

DROP TABLE IF EXISTS `pay_salary`;
CREATE TABLE IF NOT EXISTS `pay_salary` (
  `pay_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(64) DEFAULT NULL,
  `type_id` int(11) NOT NULL,
  `month` varchar(64) DEFAULT NULL,
  `year` varchar(64) DEFAULT NULL,
  `paid_date` varchar(64) DEFAULT NULL,
  `total_days` varchar(64) DEFAULT NULL,
  `basic` varchar(64) DEFAULT NULL,
  `total_gross` varchar(64) NOT NULL,
  `total_diduction` varchar(64) NOT NULL,
  `dra` varchar(64) NOT NULL,
  `medical` varchar(64) DEFAULT NULL,
  `house_rent` varchar(64) DEFAULT NULL,
  `conveyance` varchar(64) NOT NULL,
  `lta` varchar(64) NOT NULL,
  `attendance_bonus` varchar(64) NOT NULL,
  `bonus` varchar(64) DEFAULT NULL,
  `other_allowance` varchar(64) NOT NULL,
  `bima` varchar(64) DEFAULT NULL,
  `tax` varchar(64) DEFAULT NULL,
  `others` varchar(64) NOT NULL,
  `esi` varchar(64) NOT NULL,
  `professionaltax` varchar(64) NOT NULL,
  `canteen` varchar(64) NOT NULL,
  `provident_fund` varchar(64) DEFAULT NULL,
  `loan` varchar(64) DEFAULT NULL,
  `total_pay` varchar(128) DEFAULT NULL,
  `addition` int(11) NOT NULL,
  `diduction` int(11) NOT NULL,
  `status` enum('Paid','Process') DEFAULT 'Process',
  `paid_type` enum('Hand Cash','Bank') NOT NULL DEFAULT 'Bank',
  `lwf` varchar(64) NOT NULL,
  PRIMARY KEY (`pay_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pay_salary`
--

INSERT INTO `pay_salary` (`pay_id`, `emp_id`, `type_id`, `month`, `year`, `paid_date`, `total_days`, `basic`, `total_gross`, `total_diduction`, `dra`, `medical`, `house_rent`, `conveyance`, `lta`, `attendance_bonus`, `bonus`, `other_allowance`, `bima`, `tax`, `others`, `esi`, `professionaltax`, `canteen`, `provident_fund`, `loan`, `total_pay`, `addition`, `diduction`, `status`, `paid_type`, `lwf`) VALUES
(1, 'Doe1754', 0, 'November', '2021', '2021-11-30', '208', '5500', '', '', '', NULL, NULL, '', '', '', NULL, '', NULL, NULL, '', '', '', '', NULL, '0', '5499.52', 0, 0, 'Paid', 'Bank', ''),
(2, 'Doe1753', 0, 'November', '2021', '2021-11-30', '184', '13500', '', '', '', NULL, NULL, '', '', '', NULL, '', NULL, NULL, '', '', '', '', NULL, '10833', '2667.08', 0, 10833, 'Paid', 'Bank', ''),
(3, 'Smi1266', 0, 'November', '2021', '2021-11-30', '184', '7950', '', '', '', NULL, NULL, '', '', '', NULL, '', NULL, NULL, '', '', '', '', NULL, '0', '7950.64', 0, 0, 'Paid', 'Bank', ''),
(4, 'Moo1634', 0, 'November', '2021', '2021-12-01', '184', '8600', '', '', '', NULL, NULL, '', '', '', NULL, '', NULL, NULL, '', '', '', '', NULL, '0', '8600.16', 0, 0, 'Paid', 'Hand Cash', ''),
(5, 'Tho1044', 0, 'November', '2021', '2021-12-01', '184', '7000', '', '', '', NULL, NULL, '', '', '', NULL, '', NULL, NULL, '', '', '', '', NULL, '0', '6999.36', 0, 0, 'Paid', 'Bank', ''),
(6, 'Den1745', 0, 'December', '2022', '2021-12-31', '208', '5600', '', '', '', NULL, NULL, '', '', '', NULL, '', NULL, NULL, '', '', '', '', NULL, '0', '5599.36', 0, 0, 'Paid', 'Bank', ''),
(7, 'Soy1332', 0, 'September', '2024', '2024-09-27', '208', '15000', '', '', '', NULL, NULL, '', '', '', NULL, '', NULL, NULL, '', '', '', '', NULL, '0', '15000.96', 0, 0, 'Paid', 'Bank', ''),
(8, 'Rav1668', 0, 'January', '2024', '2024-09-30', '2160', '20000', '', '', '', NULL, NULL, '', '', '', NULL, '', NULL, NULL, '', '', '', '', NULL, '0', '199994.40', 0, 1000, 'Process', 'Bank', ''),
(9, 'Rav1668', 0, 'September', '2024', '2024-09-30', '200', '20000', '', '', '', NULL, NULL, '', '', '', NULL, '', NULL, NULL, '', '', '', '', NULL, '0', '18518.00', 0, 1481, 'Paid', 'Bank', ''),
(10, 'tes1397', 0, 'September', '2024', '2024-09-28', '208', '15000', '', '', '', NULL, NULL, '', '', '', NULL, '', NULL, NULL, '', '', '', '', NULL, '0', '15000.96', 0, 0, 'Paid', 'Hand Cash', ''),
(11, 'ji1648', 0, 'October', '2024', '2024-10-05', '', '500000', '', '', '', NULL, NULL, '', '', '', NULL, '', NULL, NULL, '', '', '', '', NULL, '0', '0', 0, 500000, 'Paid', 'Hand Cash', ''),
(12, 'Soy1332', 0, 'October', '2024', '2024-10-02', '23.7', '50000', '', '', '', NULL, NULL, '', '', '', NULL, '', NULL, NULL, '', '', '', '', NULL, '0', '44887', 0, 44514, 'Paid', 'Hand Cash', ''),
(13, 'Soy1332', 0, 'July', '2024', '2024-10-25', '229.5', '50000', '48735.00', '3848.00', '300', '1250', '20000.00', '1000', '100', '200', '300', '500', NULL, '100', '100', '366', '208', '300', '3048.00', '0', '44887', 3125, 0, 'Paid', 'Hand Cash', '100');

-- --------------------------------------------------------

--
-- Table structure for table `penalty`
--

DROP TABLE IF EXISTS `penalty`;
CREATE TABLE IF NOT EXISTS `penalty` (
  `id` int(11) NOT NULL,
  `penalty_name` varchar(64) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
CREATE TABLE IF NOT EXISTS `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_name` varchar(128) DEFAULT NULL,
  `pro_start_date` varchar(128) DEFAULT NULL,
  `pro_end_date` varchar(128) DEFAULT NULL,
  `pro_description` varchar(1024) DEFAULT NULL,
  `pro_summary` varchar(512) DEFAULT NULL,
  `pro_status` enum('upcoming','complete','running') NOT NULL DEFAULT 'running',
  `progress` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`id`, `pro_name`, `pro_start_date`, `pro_end_date`, `pro_description`, `pro_summary`, `pro_status`, `progress`) VALUES
(1, 'Project X23', 'Jan 4, 2022', 'Feb 2, 2022', ' This is just a demo project! This is just a demo project! This is just a demo project! This is just a demo project!', 'This is just a demo project!', 'upcoming', NULL),
(2, 'Multi User Chat System', 'Jan 1, 2022', 'April 14, 2022', ' You are required to develop a system that supports multi-user chatting with the help of top level technologies.', 'Development of Multi-User Chatting System', 'running', NULL),
(3, 'Image Enhancement Software', 'Dec 10, 2021', 'Mar 20, 2022', 'You are required to develop of computer based software where end users can receive quality results on image enhancement. This particular project requires large number of technologies with proper use and its features.', 'Development of Image Enhancement Software', 'running', NULL),
(4, 'Customer support service operation', 'Dec 25, 2021', 'Feb 16, 2022', 'You are required to develop a customer support service based operation using DotNet (.Net)', 'Develop a customer support service operation', 'running', NULL),
(5, 'Real Estate Site', 'Dec 29, 2021', 'Mar 21, 2022', ' You are required to develop a real estate website using React, Nodejs.', 'Develop a real-estate website', 'running', NULL),
(6, 'Graphics Illustration', 'Jan 2, 2022', 'Jan 10, 2022', 'You are required to make a graphic illustration for XYZ company. ', 'Make a graphic illustration for ....', 'running', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `project_file`
--

DROP TABLE IF EXISTS `project_file`;
CREATE TABLE IF NOT EXISTS `project_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_id` int(11) NOT NULL,
  `file_details` varchar(1028) DEFAULT NULL,
  `file_url` varchar(256) DEFAULT NULL,
  `assigned_to` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pro_expenses`
--

DROP TABLE IF EXISTS `pro_expenses`;
CREATE TABLE IF NOT EXISTS `pro_expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_id` int(11) NOT NULL,
  `assign_to` varchar(64) DEFAULT NULL,
  `details` varchar(512) DEFAULT NULL,
  `amount` varchar(256) DEFAULT NULL,
  `date` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pro_notes`
--

DROP TABLE IF EXISTS `pro_notes`;
CREATE TABLE IF NOT EXISTS `pro_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assign_to` varchar(64) DEFAULT NULL,
  `pro_id` int(11) NOT NULL,
  `details` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pro_task`
--

DROP TABLE IF EXISTS `pro_task`;
CREATE TABLE IF NOT EXISTS `pro_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_id` int(11) NOT NULL,
  `task_title` varchar(256) DEFAULT NULL,
  `start_date` varchar(128) DEFAULT NULL,
  `end_date` varchar(128) DEFAULT NULL,
  `image` varchar(128) DEFAULT NULL,
  `description` varchar(2048) DEFAULT NULL,
  `task_type` enum('Office','Field') NOT NULL DEFAULT 'Office',
  `status` enum('running','complete','cancel') DEFAULT 'running',
  `location` varchar(512) DEFAULT NULL,
  `return_date` varchar(128) DEFAULT NULL,
  `total_days` varchar(128) DEFAULT NULL,
  `create_date` varchar(128) DEFAULT NULL,
  `approve_status` enum('Approved','Not Approve','Rejected') NOT NULL DEFAULT 'Not Approve',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pro_task`
--

INSERT INTO `pro_task` (`id`, `pro_id`, `task_title`, `start_date`, `end_date`, `image`, `description`, `task_type`, `status`, `location`, `return_date`, `total_days`, `create_date`, `approve_status`) VALUES
(1, 1, 'Demo Task Title for Testing', '2022-01-03', '2022-01-31', NULL, 'This is demo details for testing. This is demo details for testing', 'Office', 'running', NULL, NULL, NULL, '2022-01-03', '');

-- --------------------------------------------------------

--
-- Table structure for table `pro_task_assets`
--

DROP TABLE IF EXISTS `pro_task_assets`;
CREATE TABLE IF NOT EXISTS `pro_task_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_task_id` int(11) NOT NULL,
  `assign_id` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `salary_type`
--

DROP TABLE IF EXISTS `salary_type`;
CREATE TABLE IF NOT EXISTS `salary_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_type` varchar(256) DEFAULT NULL,
  `create_date` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `salary_type`
--

INSERT INTO `salary_type` (`id`, `salary_type`, `create_date`) VALUES
(1, 'Hourly', '2017-11-22'),
(2, 'Monthly', '2017-12-30'),
(3, 'Weekly', '2017-12-29'),
(4, 'Daily', '2018-03-31');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

DROP TABLE IF EXISTS `section`;
CREATE TABLE IF NOT EXISTS `section` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `sec_name` varchar(64) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`Id`, `sec_name`) VALUES
(6, 'section III'),
(7, 'section III'),
(4, 'section I');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sitelogo` varchar(128) DEFAULT NULL,
  `sitetitle` varchar(256) DEFAULT NULL,
  `description` varchar(512) DEFAULT NULL,
  `copyright` varchar(128) DEFAULT NULL,
  `contact` varchar(128) DEFAULT NULL,
  `currency` varchar(128) DEFAULT NULL,
  `symbol` varchar(64) DEFAULT NULL,
  `system_email` varchar(128) DEFAULT NULL,
  `address` varchar(256) DEFAULT NULL,
  `address2` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `sitelogo`, `sitetitle`, `description`, `copyright`, `contact`, `currency`, `symbol`, `system_email`, `address`, `address2`) VALUES
(1, 'hrtag.png', 'H R System (CI)', 'Just a demo description and nothing else!', 'Seyon Infotech', '9043803877', 'INR', '₹', 'support@syeoninfotech.com', '#3 Kamarajar St, Thanthai Periyar Nagar, Tharamani, Chennai -600118', '');

-- --------------------------------------------------------

--
-- Table structure for table `social_media`
--

DROP TABLE IF EXISTS `social_media`;
CREATE TABLE IF NOT EXISTS `social_media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(64) DEFAULT NULL,
  `facebook` varchar(256) DEFAULT NULL,
  `twitter` varchar(256) DEFAULT NULL,
  `google_plus` varchar(512) DEFAULT NULL,
  `skype_id` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `to-do_list`
--

DROP TABLE IF EXISTS `to-do_list`;
CREATE TABLE IF NOT EXISTS `to-do_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) DEFAULT NULL,
  `to_dodata` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` varchar(128) DEFAULT NULL,
  `value` varchar(14) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `to-do_list`
--

INSERT INTO `to-do_list` (`id`, `user_id`, `to_dodata`, `date`, `value`) VALUES
(1, 'Doe1753', 'Demo Task', '2021-04-19 09:19:29pm', '1'),
(2, 'Soy1332', 'Research on X1, Y2, A3', '2022-01-02 08:27:25pm', '0'),
(3, 'Soy1332', 'Recruit Members', '2022-01-02 08:27:50pm', '1'),
(4, 'Soy1332', 'Assign Task to Dev.', '2022-01-02 08:28:04pm', '1'),
(5, 'Soy1332', 'Attend Zoom Meetings', '2022-01-03 03:10:07pm', '1'),
(6, 'Soy1332', 'HRMS Meeting ', '2024-09-27 10:56:05pm', '1');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
